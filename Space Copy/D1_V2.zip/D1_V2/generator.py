import json
import os
import datetime
from pathlib import Path

SCHEMA = {
    "thermal": ["thermal_range", "emissivity", "target_area", "frame_map"],
    "RGB": ["resolution", "fps", "shutter_speed", "focus_level"],
    "raman": ["sample_id", "wavelength_range_nm", "laser_power_mW", "integration_time_ms", "spectrum_data"],
    "actuator": ["actuator_type", "motor_id", "position_mm", "target_position_mm", "current_A", "status_code"],
    "failure_label": ["label_type", "detected_by", "confidence", "annotated_by", "verified"],
    "force_torque": ["force_N", "torque_Nm"],
    "vibration": ["vibration_rms", "frequency_Hz"],
    "gas": ["gas_type", "concentration_ppm"],
    "particle": ["particle_size_distribution"]
}

BASE_FIELDS = ["sensor_id", "units", "calibration_version", "error_state", "location", "environment"]


def iso_timestamp():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def prompt_field(name, default=None, dtype=str):
    val = input(f"{name} ({dtype.__name__}) [{default}]: ") or default
    if val is None:
        return None
    try:
        if dtype == list:
            return json.loads(val)
        return dtype(val)
    except:
        return val


def generate_metadata():
    print("\n--- Metadata Generator CLI ---")
    sensor_type = input("Enter sensor type (e.g., raman, thermal): ").strip()
    if sensor_type not in SCHEMA:
        print("\n❌ Unsupported sensor type. Check schema list.")
        return

    metadata = {
        "sensor_type": sensor_type,
        "timestamp": iso_timestamp()
    }

    for field in BASE_FIELDS:
        metadata[field] = prompt_field(field)

    for field in SCHEMA[sensor_type]:
        metadata[field] = prompt_field(field)

    out_dir = Path("generated")
    out_dir.mkdir(exist_ok=True)
    fname = f"{sensor_type}_{datetime.datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
    with open(out_dir / fname, 'w') as f:
        json.dump(metadata, f, indent=2)
        print(f"\n✅ Metadata file saved to: {out_dir / fname}\n")


if __name__ == "__main__":
    generate_metadata()

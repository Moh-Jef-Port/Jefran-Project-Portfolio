import json
import sys
import jsonschema
from jsonschema import validate
from pathlib import Path

SCHEMA_PATH = "Metadata_Schema_V2.json"



def load_schema():
    with open(SCHEMA_PATH, 'r') as f:
        return json.load(f)


def load_metadata(file_path):
    with open(file_path, 'r') as f:
        return json.load(f)


def validate_metadata(metadata, schema):
    try:
        validate(instance=metadata, schema=schema)
        print("✅ Validation successful: metadata file is valid.")
    except jsonschema.exceptions.ValidationError as err:
        print("❌ Validation failed:")
        print(err.message)
        print("\nLocation:", list(err.path))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python validate.py path/to/your_metadata.json")
        sys.exit(1)

    metadata_path = Path(sys.argv[1])
    if not metadata_path.exists():
        print("❌ File not found:", metadata_path)
        sys.exit(1)

    schema = load_schema()
    metadata = load_metadata(metadata_path)
    validate_metadata(metadata, schema)

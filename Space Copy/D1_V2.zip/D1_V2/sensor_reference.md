# Sensor Reference: Space Copy Metadata Toolkit

This document provides a brief overview of each sensor type used in Space Copy Inc.’s autonomous 3D printing and robotic systems. It explains their function, output data, and relevance to metadata.

---

## Thermal Camera
**Purpose**: Monitor temperature distribution during SLM laser fusion and FDM nozzle output.
- **Key Fields**: `thermal_range`, `emissivity`, `frame_map`, `target_area`
- **Metadata Output**: Min/max surface temp, infrared imaging data (base64)
- **Importance**: Identifies thermal defects, overheating, or undercooled regions during layer-by-layer construction.

---

## RGB / Optical Camera
**Purpose**: Capture visual layers for print quality analysis.
- **Key Fields**: `resolution`, `fps`, `shutter_speed`, `focus_level`
- **Metadata Output**: Resolution, frame timing, focus metrics
- **Importance**: Used for visual inspection, AI-based failure detection, and timelapse reconstruction.

---

## Raman Spectrometer
**Purpose**: Analyze regolith or print surface chemical composition.
- **Key Fields**: `sample_id`, `wavelength_range_nm`, `integration_time_ms`, `spectrum_data`
- **Metadata Output**: Light intensity counts across wavelength bands
- **Importance**: Validates mineral presence, detects impurities, supports in-situ verification of print material.

---

## Actuator Log (Motors)
**Purpose**: Log movement and force from stepper motors, linear actuators, brushless motors.
- **Key Fields**: `actuator_type`, `motor_id`, `position_mm`, `current_A`, `status_code`
- **Metadata Output**: Movement trace, current draw
- **Importance**: Ensures mechanical fidelity, calibrates positional accuracy, flags misalignments.

---

## Failure Label (Manual or ML-Based)
**Purpose**: Detect anomalies in the printing or handling process.
- **Key Fields**: `label_type`, `detected_by`, `confidence`, `verified`
- **Metadata Output**: Error type, detection method, ML model confidence
- **Importance**: Automates fault tracking, used for self-healing logic or logging incidents.

---

## Force/Torque Sensor
**Purpose**: Capture physical interaction data from the robot arm end-effector.
- **Key Fields**: `force_N`, `torque_Nm`
- **Metadata Output**: 6-axis force and torque measurements
- **Importance**: Prevents material damage, ensures stable contact in unknown terrain or objects.

---

## Vibration Sensor
**Purpose**: Monitor centrifuge balancing, sieve operation, or printer motor oscillation.
- **Key Fields**: `vibration_rms`, `frequency_Hz`
- **Metadata Output**: RMS amplitude, dominant frequencies
- **Importance**: Tracks wear, predicts breakdown, validates stable operation.

---

## Gas Sensor
**Purpose**: Detect oxygen or hazardous gas levels inside sealed print chambers.
- **Key Fields**: `gas_type`, `concentration_ppm`
- **Metadata Output**: PPM-level readings for specific gases
- **Importance**: Protects material quality and ensures a safe print chamber atmosphere.

---

## Particle Sensor
**Purpose**: Characterize grain size during mechanical sieving or post-crushing.
- **Key Fields**: `particle_size_distribution`
- **Metadata Output**: Array of sizes (microns)
- **Importance**: Ensures quality of powder feedstock and consistency of processed regolith.


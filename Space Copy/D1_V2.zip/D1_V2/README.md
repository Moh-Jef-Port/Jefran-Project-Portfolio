# Space Copy Metadata Generator Toolkit

A Python-based system to create, validate, and manage unified metadata files for sensor data in Space Copy’s regolith-immune 3D printer, robotic arm, and analysis systems.

---

## Project Structure
```
metadata_toolkit/
├── schema/
│   └── metadata_schema_V2.json
├── examples/
│   ├── thermal_cam_sample.json
│   ├── raman_sample.json
│   └── ... (others)
├── generator.py
├── validate.py 
├── README.md
└── sensor_reference.md
```

---

## Supported Sensor Types

| Sensor Type     | Description                                     |
|----------------|-------------------------------------------------|
| `thermal`       | Thermal cameras for laser heat distribution     |
| `RGB`           | Optical cameras for print layer inspection      |
| `raman`         | Spectroscopy head for regolith analysis         |
| `actuator`      | Motors, servos, and mechanical logs             |
| `failure_label` | AI-generated or human-labeled defect data       |
| `force_torque`  | End-effector feedback during manipulation       |
| `vibration`     | Sensor feedback from centrifuges, sieves, etc. |
| `gas`           | Oxygen or volatile gas concentration data       |
| `particle`      | Grain size distribution from sieving/crushing  |

---

## Metadata Format (Shared Fields)
```json
{
  "sensor_type": "thermal",
  "sensor_id": "thermal_01",
  "timestamp": "2025-06-21T10:30:00Z",
  "units": "deg_C",
  "calibration_version": "v3.1",
  "error_state": "OK"
}
```
> Additional sensor-specific fields will be appended automatically based on the selected sensor type.

---

## How to Use the Generator

### ▶Run the CLI:
```bash
python generator.py
```

### Options:
- Enter sensor type (e.g. `raman`)
- Fill in required metadata interactively
- Saves a file like: `generated/raman_20250621_1031.json`

### Validate Metadata File
```bash
python validate.py path/to/your_file.json
```

---

## 📐 Extending the Schema
To support a new sensor:
1. Add it to the `enum` list in the schema.
2. Define its custom fields.
3. Add sample in `/examples`
4. Update `generator.py` with prompt logic

---

## Credits
Built by **Mohamed Jefran** (Intern @ Space Copy Inc.)


---

## Built for
Extreme-environment autonomous printing systems in lunar analog conditions.

---

import json
from datetime import datetime
from jsonschema import validate, ValidationError

# Load the schema once
with open("metadata_schema.json") as schema_file:
    schema = json.load(schema_file)

def generate_metadata():
    sensor_type = input("Sensor Type (e.g., thermal_frame, rgb_image): ")
    sensor_id = input("Sensor ID: ")
    units = input("Units (e.g., °C, nm): ")
    calibration_version = input("Calibration Version: ")
    error_state = input("Error State (e.g., false, none, error_code123): ")

    metadata = {
        "timestamp": datetime.utcnow().isoformat(),
        "sensor_type": sensor_type,
        "sensor_id": sensor_id,
        "units": units,
        "calibration_version": calibration_version,
        "error_state": error_state
    }

    # Validate metadata
    try:
        validate(instance=metadata, schema=schema)
        print("✅ Metadata validated successfully.")
    except ValidationError as e:
        print(f"❌ Validation failed: {e.message}")
        return

    # Save the metadata
    filename = f"{sensor_type}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
    with open(filename, 'w') as f:
        json.dump(metadata, f, indent=2)
    print(f"📁 Metadata saved to: {filename}")

if __name__ == "__main__":
    generate_metadata()

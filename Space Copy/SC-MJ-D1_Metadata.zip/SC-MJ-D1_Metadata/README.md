# Unified Metadata Schema & Generator

## 📌 Project Overview

This project delivers a **unified JSON metadata schema** and a **template generator tool** to support structured, validated, and extensible data collection across different sensor types used in our experiments. It is designed for consistent logging and future data pipeline integration.

---

## 🎯 Objective

- Define a **single JSON Schema** that supports multiple sensor types:  
  - Thermal Frames  
  - RGB Images  
  - Raman Spectra  
  - Actuator Logs  
  - Failure Labels  

- Include core metadata fields common to all data types.
- Build a Python script that generates **blank JSON metadata files** interactively for new sessions, ensuring schema compliance and proper formatting.

---

## ⚙️ Python Script – `generate_metadata.py`

This command-line tool auto-generates a blank metadata JSON file based on user input. The script:

- Prompts for each core metadata field
- Validates entries against the schema
- Automatically adds current timestamp in ISO-8601
- Outputs a properly named file (e.g. `thermal_frame_2025-06-09T14-33-02.json`)

### ✅ Example Output
```json
{
  "timestamp": "2025-06-09T14:33:02",
  "sensor_id": "TF001",
  "units": "°C",
  "calibration_version": "v1.0.2",
  "error_state": false,
  "sensor_type": "thermal_frame"
}


Summary of Deliverables

✔ Single unified JSON Schema with extensibility
✔ Example metadata files for all required sensor types
✔ Python script that generates new metadata files based on schema
✔ Input validation and auto-timestamping
✔ Clean project structure ready for integration or extension

Author: 
--> Mohamed Jefran
--> Internship Project Deliverable – Metadata Schema & Generator
--> Date: June 2025

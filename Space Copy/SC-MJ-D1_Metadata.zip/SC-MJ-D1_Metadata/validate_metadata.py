import json
from jsonschema import validate, ValidationError

def validate_file(filename):
    with open("metadata_schema.json") as schema_file:
        schema = json.load(schema_file)

    with open(filename) as metadata_file:
        metadata = json.load(metadata_file)

    try:
        validate(instance=metadata, schema=schema)
        print(f"✅ {filename} is valid.")
    except ValidationError as e:
        print(f"❌ {filename} is invalid: {e.message}")

if __name__ == "__main__":
    fname = input("Enter metadata file name to validate: ")
    validate_file(fname)

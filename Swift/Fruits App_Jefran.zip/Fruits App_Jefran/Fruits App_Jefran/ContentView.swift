//
//  ContentView.swift
//  Fruits App_Jefran
//
//  Created by Mohamed Jefran on 07/08/2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(spacing: 70) {
            Text("Fruits are full of Vitamins")
                .font(.title) //For Size
                .bold() //For Bold
                .italic() //For Italics
                .foregroundStyle(.blue) //For Text Color
                .textScale(.secondary) //Scaling to secondary text
                .multilineTextAlignment(.center) //multiple line display
                .lineLimit(2) //how many line want to be displayed
                .truncationMode(.tail) //
                .padding()
                .background(.yellow) //background of text
                
            
            
            HStack {
                     VStack {
                         Image("apple")
                             .resizable()
                             .scaledToFit()
                         Text("Apple")
                             .bold()
                             .font(.title)
                     }
                     VStack {
                         Image("watermelon")
                             .resizable()
                             .scaledToFit()
                         Text("Watermelon")
                             .bold()
                             .font(.title)
                     }
                 }
                 
                 HStack {
                     VStack {
                         Image("orange")
                             .resizable()
                             .scaledToFit()
                         Text("Orange")
                             .bold()
                             .font(.title)
                     }
                     VStack {
                         Image("banana")
                             .resizable()
                             .scaledToFit()
                         Text("Banana")
                             .bold()
                             .font(.title)
                     }
                 }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}

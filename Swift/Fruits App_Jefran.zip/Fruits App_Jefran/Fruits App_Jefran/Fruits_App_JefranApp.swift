//
//  Fruits_App_JefranApp.swift
//  Fruits App_Jefran
//
//  Created by Mohamed Jefran on 07/08/2024.
//

import SwiftUI

@main
struct Fruits_App_JefranApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

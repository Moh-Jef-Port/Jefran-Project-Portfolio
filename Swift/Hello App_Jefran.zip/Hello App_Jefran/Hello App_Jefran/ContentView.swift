//
//  ContentView.swift
//  Hello App_Jefran
//
//  Created by Mohamed Jefran on 05/08/2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image("My Face")
                .resizable()
                .scaledToFit()
                .clipShape(Circle())
                .shadow(radius: 20)
         Text("My Name Is Mohamed Jefran")
                .bold()
                .font(.title2)
            Text("Entrepreuner")
                .bold()
                .font(.title3)
                .foregroundStyle(.tint)
        }
        .padding()
    }
}

#Preview {
    ContentView()
}

//
//  Hello_App_JefranApp.swift
//  Hello App_Jefran
//
//  Created by Mohamed Jefran on 05/08/2024.
//

import SwiftUI

@main
struct Hello_App_JefranApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  ContentView.swift
//  Fine Calculator
//
//  Created by Mohamed Jefran on 11/08/2024.
//

import SwiftUI

struct ContentView: View {
    
    @State private var speed = "0"
    @State private var result = ""
    @State var fine = ""
    
    var body: some View {
        VStack {
            
            Image("Police")
                .padding()
            
            Text("Fine Calculator - Speed Limit 120 Km/h")
                .bold()
                .font(.title)
                .multilineTextAlignment(.center)
            
            TextField("Speed Of Car", text: $speed)
                .keyboardType(.decimalPad)
                .frame(width: 150)
                .font(.title3)
                .border(Color.gray, width: 1)
        
            Button("Calculate Fine") {
                // Convert the speed to an integer
                if let speedValue = Int(speed) {
                    let speedLimit = 120
                    var overSpeed = speedValue - speedLimit
                    
                    if overSpeed > 0 {
                        if overSpeed <= 20 {
                            fine = "400 AED"
                        } else if overSpeed <= 30 {
                            fine = "600 AED"
                        } else if overSpeed <= 40 {
                            fine = "800 AED"
                        } else if overSpeed <= 50 {
                            fine = "1000 AED"
                        } else {
                            fine = "Confiscation & Court Appearance required"
                        }
                        
                        result = "The Fine is \(fine)"
                    } else {
                        result = "You have No Fine - Very Good Driver"
                    }
                } else {
                    result = "Please enter a valid speed."
                }
            }
            .padding()
            .frame(width: 300, height: 75)
            .font(.title)
            .background(Color.black)
            .foregroundColor(.white)
            .cornerRadius(15)
            
            Text(result)
                .font(.title)
        }
        .padding()
    }
}

#Preview {
    ContentView()
}

//
//  Fine_CalculatorApp.swift
//  Fine Calculator
//
//  Created by Mohamed Jefran on 11/08/2024.
//

import SwiftUI

@main
struct Fine_CalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

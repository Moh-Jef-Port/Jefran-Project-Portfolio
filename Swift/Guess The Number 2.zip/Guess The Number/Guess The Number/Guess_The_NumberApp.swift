//
//  Guess_The_NumberApp.swift
//  Guess The Number
//
//  Created by Mohamed Jefran on 12/08/2024.
//

import SwiftUI

@main
struct Guess_The_NumberApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

import SwiftUI

struct ContentView: View {

    // Declarations of all required Variables

    @State private var AnswerCorrect = false
    @State private var Difficulty = 10.0
    @State private var RandomNumber = 0
    @State private var Answer = ""
    @State private var Tries = 0
    @State private var ResultLocal = ""
    @State private var animationAmount: CGFloat = 1.0
    @State private var isAnswerRevealed = false
    @State private var hintMessage = ""

    var body: some View {
        ZStack {
            // Changing Color of Background Depending on answer
            Color(AnswerCorrect ? UIColor.green : UIColor.black)
                .ignoresSafeArea()

            VStack(spacing: 20) {
                HStack {
                    Text("Play Guess the Number Below!")
                        .foregroundStyle(.white)
                        .font(.title)
                        .bold()
                        .multilineTextAlignment(.center)
                        .padding()
                        .background(.orange)
                        .clipShape(RoundedRectangle(cornerSize: CGSize(width: 20, height: 10)))
                        .offset(x: -0, y: 20)

                    Button("Play Again") {
                        resetGame()
                    }
                    .padding()
                    .font(.title2)
                    .bold()
                    .background(.orange)
                    .foregroundStyle(.black)
                    .cornerRadius(15)
                    .clipShape(RoundedRectangle(cornerSize: CGSize(width: 20, height: 10)))
                    .offset(x: -0, y: 20)
                }

                Image(systemName: "brain.head.profile.fill")
                    .foregroundStyle(.white)
                    .font(.system(size: 150))

                Text("Set Your Guessing Range (0 - ?)")
                    .foregroundStyle(.white)
                    .font(.title2)
                    .bold()

                Text("Current Difficulty set = \(Difficulty)")
                    .foregroundStyle(.white)
                    .font(.title2)

                HStack {
                    VStack {
                        Slider(value: $Difficulty, in: 10...1000, step: 10) {
                            Text("Difficulty")
                        } minimumValueLabel: {
                            Text("10")
                                .foregroundStyle(.white)
                        } maximumValueLabel: {
                            Text("1000")
                                .foregroundStyle(.white)
                        }

                        Text(String(format: "%.2f", Difficulty))
                            .foregroundStyle(.white)
                            .bold()
                            .font(.title2)
                    }

                    Button("Set Difficulty") {
                        setRandomNumber()
                    }
                    .padding()
                    .font(.title)
                    .background(.red)
                    .foregroundStyle(.white)
                    .cornerRadius(20)
                    .disabled(isAnswerRevealed)
                }

                TextField("Your Guess", text: $Answer)
                    .background(.white)
                    .keyboardType(.decimalPad)
                    .frame(width: 300)
                    .font(.title3)
                    .multilineTextAlignment(.center)
                    .border(Color.green, width: 2)

                Button("Submit") {
                    checkAnswer()
                }
                .padding()
                .frame(width: 250, height: 50)
                .font(.title)
                .background(Color.white)
                .foregroundColor(.black)
                .cornerRadius(15)
                .disabled(isAnswerRevealed)

                Text(ResultLocal)
                    .foregroundStyle(.white)
                    .font(.title)
                    .scaleEffect(animationAmount)
                    .opacity(Double(2.0 - animationAmount))
                    .animation(.easeInOut(duration: 0.5), value: animationAmount)

                // Hints Message Display
                Text(hintMessage)
                    .foregroundStyle(.yellow)
                    .font(.title3)
                    .bold()

                HStack {
                    Button("Reveal Answer") {
                        revealAnswer()
                    }
                    .padding()
                    .font(.title2)
                    .background(.green)
                    .foregroundStyle(.red)
                    .cornerRadius(15)
                    .disabled(isAnswerRevealed)

                    Text("Number of Tries: \(Tries)")
                        .foregroundStyle(.white)
                        .bold()
                        .font(.title2)
                }
            }
        }
    }

    // Reset game function to reset all variables to prevent cheating
    func resetGame() {
        AnswerCorrect = false
        Difficulty = 10.0
        RandomNumber = 0
        Answer = ""
        Tries = 0
        ResultLocal = ""
        isAnswerRevealed = false
        hintMessage = ""
    }

    // Function to generate a random number between a range to guess
    func setRandomNumber() {
        let DifficultySet = Difficulty
        RandomNumber = Int.random(in: 1...Int(DifficultySet))
    }

    // Function to increment the number of tries and to check the answer
    func checkAnswer() {
        Tries += 1

        if let answerInt = Int(Answer) {
            if answerInt == RandomNumber {
                ResultLocal = "Hooray You Made It!"
                AnswerCorrect = true
            } else if (RandomNumber - 10...RandomNumber + 10).contains(answerInt) {
                ResultLocal = "You are very close!"
                animateCorrectness(isClose: true)
            } else if (RandomNumber - 20...RandomNumber + 20).contains(answerInt) {
                ResultLocal = "You are getting close, around 20 units away."
                animateCorrectness(isClose: true)
            } else if answerInt > Int(Difficulty) {
                ResultLocal = "Enter a valid number - out of range"
            } else {
                ResultLocal = "You are not close, keep guessing."
                animateCorrectness(isClose: false)
            }

            // Generate hint based on the number of tries
            if Tries >= 3 && Tries < 6 {
                hintMessage = RandomNumber % 2 == 0 ? "Hint: The number is even." : "Hint: The number is odd."
            } else if Tries >= 6 {
                hintMessage = "Hint: The number is between \(RandomNumber - 5) and \(RandomNumber + 5)."
            }
        } else {
            ResultLocal = "Please enter a valid number."
        }
    }

    // Function to reveal the answer when reveal button is pressed and flag value change to prevent cheating
    func revealAnswer() {
        ResultLocal = "The answer is \(RandomNumber)"
        isAnswerRevealed = true
    }

    // Function to animate the correctness of the answer
    func animateCorrectness(isClose: Bool) {
        withAnimation(.easeInOut(duration: 1.0)) {
            animationAmount = isClose ? 1.5 : 0.8
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            withAnimation {
                animationAmount = 1.0
            }
        }
    }
}

#Preview {
    ContentView()
}

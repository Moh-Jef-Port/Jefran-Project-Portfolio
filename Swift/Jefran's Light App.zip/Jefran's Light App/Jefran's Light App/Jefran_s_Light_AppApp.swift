//
//  Jefran_s_Light_AppApp.swift
//  Jefran's Light App
//
//  Created by Mohamed Jefran on 05/08/2024.
//

import SwiftUI

@main
struct Jefran_s_Light_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  ContentView.swift
//  Jefran's Light App
//
//  Created by Mohamed Jefran on 05/08/2024.
//

import SwiftUI


struct ContentView: View {
    
    @State private var lightOn = false
    
    var body: some View {
        ZStack {
            Color( lightOn ? UIColor.red : UIColor.green)

        }
        .ignoresSafeArea()
        .onTapGesture {
            self.lightOn.toggle() //Changing to true or false
        }
    }
}

#Preview {
    ContentView()
}
